define(function() {var keywords=[{w:"Mounting",p:["p0","p2","p3"]},{w:"and",p:["p0","p2","p3"]},{w:"Matting",p:["p0","p2","p3"]},{w:"Art",p:["p0","p2"]},{w:"Overview",p:["p0"]},{w:"frame",p:["p1"]},{w:"size",p:["p1"]},{w:"Reference",p:["p2"]},{w:"for",p:["p2"]},{w:"Procedures",p:["p3"]},{w:"window",p:["p4"]},{w:"mat",p:["p4"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3, 4];
ph["p1"]=[5, 6];
ph["p2"]=[7, 8, 0, 1, 2, 3];
ph["p3"]=[0, 1, 2, 9];
ph["p4"]=[10, 11];
     return {
         keywords: keywords,
         ph: ph
     }
});

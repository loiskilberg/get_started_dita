define(function() {var keywords=[{w:"Tuning",p:["p0","p1","p2"]},{w:"a",p:["p0"]},{w:"Piano",p:["p0","p1"]},{w:"Introduction",p:["p0"]},{w:"References",p:["p1"]},{w:"for",p:["p1"]},{w:"Each",p:["p2"]},{w:"Octave",p:["p2"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3];
ph["p1"]=[4, 5, 2, 0];
ph["p2"]=[0, 6, 7];
     return {
         keywords: keywords,
         ph: ph
     }
});
